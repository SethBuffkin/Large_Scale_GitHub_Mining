
<?php
var_dump(phpversion("mongodb"));
?>
